/**
 * overlays.js — toasts, help modal, loading screen, empty state.
 */

import { el } from "./dom.js";

/* ------------------------------------------------------------------ toast */

const MAX_TOASTS = 3;

export function toast(message, tone = "default", duration = 1800) {
  const node = document.createElement("div");
  node.className = "toast";
  node.dataset.tone = tone;
  node.innerHTML = '<span class="toast-dot"></span><span></span>';
  node.lastElementChild.textContent = message;
  el.toasts.appendChild(node);

  while (el.toasts.children.length > MAX_TOASTS) {
    el.toasts.firstElementChild.remove();
  }

  setTimeout(() => {
    node.classList.add("out");
    setTimeout(() => node.remove(), 240);
  }, duration);
}

/* ------------------------------------------------------------------- help */

let helpReturnFocus = null;

export function openHelp() {
  helpReturnFocus = document.activeElement;
  el.helpOverlay.hidden = false;
  el.helpClose.focus({ preventScroll: true });
}

export function closeHelp() {
  el.helpOverlay.hidden = true;
  if (helpReturnFocus && helpReturnFocus.focus) helpReturnFocus.focus({ preventScroll: true });
}

export function initOverlays() {
  el.helpClose.addEventListener("click", closeHelp);
  el.helpOverlay.addEventListener("click", (e) => {
    if (e.target === el.helpOverlay) closeHelp();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !el.helpOverlay.hidden) closeHelp();
  });
}

/* ---------------------------------------------------------------- loading */

export function showLoading(text = "Starting…") {
  el.loading.hidden = false;
  el.loadingSpinner.style.display = "";
  el.loadingText.textContent = text;
  el.loadingRetry.hidden = true;
}

export function setLoadingText(text) {
  el.loadingText.textContent = text;
}

export function hideLoading() {
  el.loading.hidden = true;
}

export function showLoadingError(message, onRetry) {
  el.loading.hidden = false;
  el.loadingSpinner.style.display = "none";
  el.loadingText.innerHTML = message;
  el.loadingRetry.hidden = false;
  el.loadingRetry.onclick = () => {
    el.loadingSpinner.style.display = "";
    el.loadingText.textContent = "Starting…";
    el.loadingRetry.hidden = true;
    onRetry && onRetry();
  };
}

/* ------------------------------------------------------------ empty state */

export function setEmptyState(visible) {
  el.empty.hidden = !visible;
}
