/**
 * theme.js — theme switching + artboard colour sync.
 *
 * The original app kept the canvas background as an independent colour that
 * never followed the theme, which made the Light theme unusable. Here the
 * artboard colours are derived from the active theme unless the user has
 * explicitly customised them.
 */

import { state, emit, saveSettings } from "../state.js";
import { el } from "./dom.js";

const THEME_BG = {
  dark: { color: "#0b1220", color2: "#101a2b" },
  light: { color: "#ffffff", color2: "#eef2f7" },
  neon: { color: "#0a0614", color2: "#170a2b" },
};

export function applyTheme(name, { keepArtboard = false } = {}) {
  state.theme = name;
  document.body.setAttribute("data-theme", name);

  for (const btn of el.themeButtons) {
    btn.setAttribute("aria-pressed", String(btn.dataset.themeBtn === name));
  }

  if (!keepArtboard) {
    const bg = THEME_BG[name] || THEME_BG.dark;
    state.background.color = bg.color;
    state.background.color2 = bg.color2;
    if (el.bgColor) el.bgColor.value = bg.color;
    if (el.bgColor2) el.bgColor2.value = bg.color2;
    emit("background");
  }

  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) {
    meta.setAttribute("content", name === "light" ? "#eef2f7" : name === "neon" ? "#05040a" : "#080b11");
  }

  saveSettings();
}

export function initTheme() {
  const prefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
  const initial = state.theme || (prefersLight ? "light" : "dark");
  applyTheme(initial, { keepArtboard: true });

  for (const btn of el.themeButtons) {
    btn.addEventListener("click", () => {
      applyTheme(btn.dataset.themeBtn);
    });
  }
}
