/**
 * dom.js — cached element references. Imported once, queried once.
 */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export const el = {
  app: $(".app"),
  stage: $(".stage"),

  bgCanvas: $("#bg-canvas"),
  artCanvas: $("#art-canvas"),
  fxCanvas: $("#fx-canvas"),

  sidebar: $("#sidebar"),
  sheetHandle: $("#sheet-handle"),
  sheetToggle: $("#sheet-toggle"),

  modeButtons: $$("[data-mode]"),
  fillButtons: $$("[data-fill]"),
  themeButtons: $$("[data-theme-btn]"),

  // Built at runtime by controls.js, so resolve them lazily.
  get shapeButtons() {
    return $$("[data-shape]");
  },
  get bgButtons() {
    return $$("[data-bg]");
  },

  colorPicker: $("#color-picker"),
  colorFill: $("#color-fill"),
  sizeSlider: $("#size-slider"),
  sizeValue: $("#size-value"),
  opacitySlider: $("#opacity-slider"),
  opacityValue: $("#opacity-value"),

  bgColor: $("#bg-color"),
  bgColorFill: $("#bg-color-fill"),
  bgColor2: $("#bg-color2"),
  bgColor2Fill: $("#bg-color2-fill"),
  bgColor2Row: $("#bg-color2-row"),

  undoBtn: $("#undo-btn"),
  redoBtn: $("#redo-btn"),
  clearBtn: $("#clear-btn"),
  savePng: $("#save-png"),
  saveSvg: $("#save-svg"),
  copyPng: $("#copy-png"),
  exportScale: $("#export-scale"),
  transparentToggle: $("#transparent-toggle"),

  physicsToggle: $("#physics-toggle"),
  soundToggle: $("#sound-toggle"),
  skeletonToggle: $("#skeleton-toggle"),
  gridToggle: $("#grid-toggle"),

  fullscreenBtn: $("#fullscreen-btn"),
  helpBtn: $("#help-btn"),
  cameraBtn: $("#camera-btn"),

  hud: $("#hud"),
  hudRing: $("#hud-ring-fill"),
  hudEmoji: $("#hud-emoji"),
  hudGesture: $("#hud-gesture"),
  hudHint: $("#hud-hint"),

  cam: $("#cam"),
  video: $("#webcam"),

  textWrap: $("#text-wrap"),
  textInput: $("#text-input"),

  toasts: $("#toasts"),
  empty: $("#empty-state"),
  objCount: $("#obj-count"),

  statusDot: $("#status-dot"),
  statusText: $("#status-text"),

  helpOverlay: $("#help-overlay"),
  helpClose: $("#help-close"),
  helpCamera: $("#help-camera"),
  helpMouse: $("#help-mouse"),

  loading: $("#loading"),
  loadingText: $("#loading-text"),
  loadingRetry: $("#loading-retry"),
  loadingSpinner: $("#loading-spinner"),
};

export { $, $$ };
