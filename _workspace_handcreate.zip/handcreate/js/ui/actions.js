/**
 * actions.js — every user intent in one place.
 * Both the sidebar (controls.js) and the gesture engine (hands.js) call these,
 * so behaviour can never drift between mouse and camera.
 */

import { state, emit, saveSettings } from "../state.js";
import { MODES, PALETTE, SIZE_STEPS, SHAPES } from "../config.js";
import { undo, redo, commit } from "../core/history.js";
import { requestArt, requestFx } from "../core/canvas.js";
import { updateCursor, deleteSelected, cancelLine } from "../input/pointer.js";
import { downloadPng, copyPng } from "../export/png.js";
import { downloadSvg } from "../export/svg.js";
import { play } from "../audio.js";
import { toast, setEmptyState } from "./overlays.js";

/* ------------------------------------------------------------------ modes */

export function setMode(mode) {
  if (!MODES.includes(mode)) return;
  state.mode = mode;
  state.lineStart = null;
  cancelLine();
  emit("mode", mode);
  updateCursor();
  play("mode");
  saveSettings();
}

export function cycleMode() {
  const i = MODES.indexOf(state.mode);
  setMode(MODES[(i + 1) % MODES.length]);
  toast(`Mode → ${state.mode}`, "accent", 900);
}

/* ------------------------------------------------------------------ shape */

export function setShape(shape) {
  if (!SHAPES.includes(shape)) return;
  state.shape = shape;
  emit("style");
  saveSettings();
}

export function cycleShape() {
  const i = SHAPES.indexOf(state.shape);
  setShape(SHAPES[(i + 1) % SHAPES.length]);
  toast(`Shape → ${state.shape}`, "accent", 900);
}

export function setFilled(filled) {
  state.filled = filled;
  emit("style");
  saveSettings();
}

export function toggleFilled() {
  setFilled(!state.filled);
  toast(state.filled ? "Fill → solid" : "Fill → hollow", "accent", 900);
  play("mode");
}

/* ----------------------------------------------------------------- colour */

export function setColor(color) {
  state.color = color;
  const idx = PALETTE.indexOf(color);
  if (idx !== -1) state.colorIndex = idx;
  emit("style");
  saveSettings();
}

export function cycleColor() {
  state.colorIndex = (state.colorIndex + 1) % PALETTE.length;
  setColor(PALETTE[state.colorIndex]);
  toast(`Colour → ${state.color}`, "accent", 900);
  play("color");
}

/* ------------------------------------------------------------------- size */

export function setSize(size) {
  state.size = size;
  const idx = SIZE_STEPS.indexOf(size);
  if (idx !== -1) state.sizeIndex = idx;
  emit("style");
  saveSettings();
}

export function cycleSize() {
  state.sizeIndex = (state.sizeIndex + 1) % SIZE_STEPS.length;
  setSize(SIZE_STEPS[state.sizeIndex]);
  toast(`Size → ${state.size}`, "accent", 900);
  play("color");
}

/* -------------------------------------------------------------- appearance */

export function setOpacity(value) {
  state.opacity = value;
  emit("style");
  saveSettings();
}

export function setBackground(preset) {
  state.background.preset = preset;
  emit("background");
  saveSettings();
}

export function setBackgroundColors(color, color2) {
  if (color) state.background.color = color;
  if (color2) state.background.color2 = color2;
  emit("background");
  saveSettings();
}

export function setGrid(on) {
  state.showGrid = on;
  emit("background");
  saveSettings();
}

/* ------------------------------------------------------------------ edit */

export function doUndo() {
  if (undo()) {
    play("tick");
    toast("Undo", "default", 800);
  } else {
    toast("Nothing to undo", "default", 900);
  }
}

export function doRedo() {
  if (redo()) {
    play("tick");
    toast("Redo", "default", 800);
  } else {
    toast("Nothing to redo", "default", 900);
  }
}

export function clearAll() {
  if (!state.objects.length) {
    toast("Canvas is already empty", "default", 1000);
    return;
  }
  commit();
  state.objects = [];
  state.selectedId = null;
  emit("objects");
  emit("selection", null);
  setEmptyState(true);
  play("erase");
  toast("Canvas cleared", "danger", 1200);
}

export function removeSelected() {
  return deleteSelected();
}

/* ---------------------------------------------------------------- export */

export function exportPng() {
  if (!state.objects.length) {
    toast("Nothing to export yet", "default", 1200);
    return;
  }
  downloadPng({ scale: state.exportScale, transparent: state.transparentExport });
  toast("PNG saved", "accent", 1200);
  play("place");
}

export function exportSvg() {
  if (!state.objects.length) {
    toast("Nothing to export yet", "default", 1200);
    return;
  }
  downloadSvg({ transparent: state.transparentExport });
  toast("SVG saved", "accent", 1200);
  play("place");
}

export async function copyToClipboard() {
  if (!state.objects.length) {
    toast("Nothing to copy yet", "default", 1200);
    return;
  }
  try {
    await copyPng({ scale: state.exportScale, transparent: state.transparentExport });
    toast("Copied to clipboard", "accent", 1400);
  } catch (err) {
    toast(err.message || "Copy failed", "danger", 2000);
  }
}

/* ---------------------------------------------------------------- toggles */

export function setPhysics(on) {
  state.physics = on;
  emit("settings");
  saveSettings();
}

export function setSound(on) {
  state.sound = on;
  emit("settings");
  saveSettings();
}

export function setSkeleton(on) {
  state.skeleton = on;
  emit("settings");
  saveSettings();
  requestFx();
}

export function setExportScale(scale) {
  state.exportScale = scale;
  saveSettings();
}

export function setTransparentExport(on) {
  state.transparentExport = on;
  saveSettings();
  requestArt();
}
