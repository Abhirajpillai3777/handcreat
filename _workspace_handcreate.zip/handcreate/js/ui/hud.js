/**
 * hud.js — gesture HUD + status bar.
 *
 * The original rebuilt the HUD with innerHTML on every animation frame.
 * Here we only touch the DOM when a value actually changes, and the ring
 * animates via stroke-dashoffset so users can see *when* a gesture fires.
 */

import { el } from "./dom.js";

const RING_LENGTH = 126;

const last = {
  emoji: "",
  label: "",
  hint: "",
  progress: -1,
  idle: null,
  status: "",
  live: null,
};

export function setHud({ emoji, label, hint, progress = 0, idle = false }) {
  if (emoji !== undefined && emoji !== last.emoji) {
    el.hudEmoji.textContent = emoji;
    last.emoji = emoji;
  }
  if (label !== undefined && label !== last.label) {
    el.hudGesture.textContent = label;
    last.label = label;
  }
  if (hint !== undefined && hint !== last.hint) {
    el.hudHint.textContent = hint;
    last.hint = hint;
  }
  const p = Math.max(0, Math.min(1, progress));
  if (Math.abs(p - last.progress) > 0.01) {
    el.hudRing.style.strokeDashoffset = String(RING_LENGTH * (1 - p));
    last.progress = p;
  }
  if (idle !== last.idle) {
    el.hud.dataset.idle = String(idle);
    last.idle = idle;
  }
}

export function setStatus(text, live = false) {
  if (text !== last.status) {
    el.statusText.textContent = text;
    last.status = text;
  }
  if (live !== last.live) {
    el.statusDot.dataset.live = String(live);
    last.live = live;
  }
}

