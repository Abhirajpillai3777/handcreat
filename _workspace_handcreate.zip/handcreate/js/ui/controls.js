/**
 * controls.js — wires the sidebar and topbar to actions.js.
 */

import { state, on } from "../state.js";
import { SHAPES, SHAPE_LABELS, BG_PRESETS } from "../config.js";
import { shapePath } from "../core/shapes.js";
import * as A from "./actions.js";
import { el } from "./dom.js";
import { toast, openHelp } from "./overlays.js";
import { toggleFullscreen } from "../input/keyboard.js";
import { startCamera, stopCamera } from "../input/hands.js";
import { commitText } from "../input/pointer.js";

/* ---------------------------------------------------------- shape buttons */

function buildShapeGrid() {
  const grid = document.getElementById("shape-grid");
  if (!grid) return;
  grid.innerHTML = "";

  for (const shape of SHAPES) {
    const btn = document.createElement("button");
    btn.className = "shape-btn";
    btn.type = "button";
    btn.dataset.shape = shape;
    btn.dataset.tip = SHAPE_LABELS[shape];
    btn.setAttribute("aria-label", SHAPE_LABELS[shape]);
    btn.setAttribute("aria-pressed", "false");
    btn.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${shapePath(shape, 12, 12, 8)}"/></svg>`;
    btn.addEventListener("click", () => {
      A.setShape(shape);
      A.setMode("shape");
    });
    grid.appendChild(btn);
  }
}

/* --------------------------------------------------------------- sync UI */

export function syncUI() {
  for (const b of el.modeButtons) {
    b.setAttribute("aria-pressed", String(b.dataset.mode === state.mode));
  }
  for (const b of el.shapeButtons) {
    b.setAttribute("aria-pressed", String(b.dataset.shape === state.shape));
  }
  for (const b of el.fillButtons) {
    b.setAttribute("aria-pressed", String((b.dataset.fill === "true") === state.filled));
  }
  for (const b of el.bgButtons) {
    b.setAttribute("aria-pressed", String(b.dataset.bg === state.background.preset));
  }

  if (el.colorPicker.value !== state.color) el.colorPicker.value = state.color;
  el.colorFill.style.background = state.color;

  el.sizeSlider.value = String(state.size);
  el.sizeValue.textContent = String(state.size);

  el.opacitySlider.value = String(Math.round(state.opacity * 100));
  el.opacityValue.textContent = `${Math.round(state.opacity * 100)}%`;

  el.bgColor.value = state.background.color;
  if (el.bgColorFill) el.bgColorFill.style.background = state.background.color;
  el.bgColor2.value = state.background.color2;
  if (el.bgColor2Fill) el.bgColor2Fill.style.background = state.background.color2;
  el.bgColor2Row.hidden = state.background.preset !== "gradient";

  el.physicsToggle.setAttribute("aria-checked", String(state.physics));
  el.soundToggle.setAttribute("aria-checked", String(state.sound));
  el.skeletonToggle.setAttribute("aria-checked", String(state.skeleton));
  el.gridToggle.setAttribute("aria-checked", String(state.showGrid));
  el.transparentToggle.setAttribute("aria-checked", String(state.transparentExport));

  el.exportScale.value = String(state.exportScale);
  el.objCount.textContent = `${state.objects.length} object${state.objects.length === 1 ? "" : "s"}`;
}

/* ------------------------------------------------------------ background */

function buildBackgroundGrid() {
  const grid = document.getElementById("bg-grid");
  if (!grid) return;
  grid.innerHTML = "";

  const previews = {
    grid: "repeating-linear-gradient(0deg,rgba(148,163,184,.35) 0 1px,transparent 1px 8px), repeating-linear-gradient(90deg,rgba(148,163,184,.35) 0 1px,transparent 1px 8px), #0b1220",
    dots: "radial-gradient(circle at 3px 3px, rgba(148,163,184,.6) 1px, transparent 1.5px) 0 0/8px 8px, #0b1220",
    solid: "#0b1220",
    gradient: "linear-gradient(135deg,#0b1220,#1b2a44)",
    blueprint: "repeating-linear-gradient(0deg,rgba(120,190,255,.35) 0 1px,transparent 1px 10px), repeating-linear-gradient(90deg,rgba(120,190,255,.35) 0 1px,transparent 1px 10px), #0a2540",
    paper: "#f6f1e7",
  };

  for (const preset of BG_PRESETS) {
    const btn = document.createElement("button");
    btn.className = "bg-btn";
    btn.type = "button";
    btn.dataset.bg = preset.id;
    btn.setAttribute("aria-label", `${preset.label} background`);
    btn.setAttribute("aria-pressed", "false");
    btn.style.background = previews[preset.id] || "#0b1220";
    btn.innerHTML = `<span>${preset.label}</span>`;
    btn.addEventListener("click", () => {
      A.setBackground(preset.id);
      syncUI();
    });
    grid.appendChild(btn);
  }
}

/* ----------------------------------------------------------------- wiring */

export function initControls() {
  buildShapeGrid();
  buildBackgroundGrid();

  for (const b of el.modeButtons) {
    b.addEventListener("click", () => {
      A.setMode(b.dataset.mode);
      syncUI();
    });
  }

  for (const b of el.fillButtons) {
    b.addEventListener("click", () => {
      A.setFilled(b.dataset.fill === "true");
      syncUI();
    });
  }

  el.colorPicker.addEventListener("input", (e) => {
    A.setColor(e.target.value);
    syncUI();
  });

  el.sizeSlider.addEventListener("input", (e) => {
    A.setSize(Number(e.target.value));
    syncUI();
  });
  el.opacitySlider.addEventListener("input", (e) => {
    A.setOpacity(Number(e.target.value) / 100);
    syncUI();
  });

  el.bgColor.addEventListener("input", (e) => A.setBackgroundColors(e.target.value, null));
  el.bgColor2.addEventListener("input", (e) => A.setBackgroundColors(null, e.target.value));

  el.undoBtn.addEventListener("click", A.doUndo);
  el.redoBtn.addEventListener("click", A.doRedo);
  el.clearBtn.addEventListener("click", A.clearAll);

  el.savePng.addEventListener("click", A.exportPng);
  el.saveSvg.addEventListener("click", A.exportSvg);
  el.copyPng.addEventListener("click", A.copyToClipboard);
  el.exportScale.addEventListener("change", (e) => {
    A.setExportScale(Number(e.target.value));
    toast(`Export scale ${e.target.value}×`, "default", 900);
  });
  el.transparentToggle.addEventListener("click", () => {
    A.setTransparentExport(!state.transparentExport);
    syncUI();
  });

  el.physicsToggle.addEventListener("click", () => {
    A.setPhysics(!state.physics);
    syncUI();
    toast(state.physics ? "Physics on" : "Physics off", "default", 900);
  });
  el.soundToggle.addEventListener("click", () => {
    A.setSound(!state.sound);
    syncUI();
    toast(state.sound ? "Sound on" : "Sound off", "default", 900);
  });
  el.skeletonToggle.addEventListener("click", () => {
    A.setSkeleton(!state.skeleton);
    syncUI();
  });
  el.gridToggle.addEventListener("click", () => {
    A.setGrid(!state.showGrid);
    syncUI();
  });

  el.fullscreenBtn.addEventListener("click", toggleFullscreen);
  el.helpBtn.addEventListener("click", openHelp);

  el.cameraBtn.addEventListener("click", () => {
    if (state.cameraActive) {
      stopCamera();
      toast("Camera stopped", "default", 1200);
    } else {
      startCamera();
    }
    el.cameraBtn.classList.toggle("accent", !state.cameraActive);
  });

  el.helpCamera.addEventListener("click", () => {
    el.helpOverlay.hidden = true;
    startCamera();
  });
  el.helpMouse.addEventListener("click", () => {
    el.helpOverlay.hidden = true;
    toast("Mouse mode — click and drag to draw", "accent", 2000);
  });

  const toggleSheet = () => {
    const open = el.sidebar.dataset.open === "true";
    el.sidebar.dataset.open = String(!open);
  };
  el.sheetToggle?.addEventListener("click", toggleSheet);
  el.sheetHandle?.addEventListener("click", toggleSheet);

  el.textInput.addEventListener("blur", () => {
    if (el.textWrap.dataset.open === "true") commitText();
  });

  /* ---- react to state changes coming from gestures ---- */
  on("mode", syncUI);
  on("style", syncUI);
  on("background", syncUI);
  on("settings", syncUI);
  on("objects", syncUI);
  on("history", (s) => {
    el.undoBtn.disabled = !s.canUndo;
    el.redoBtn.disabled = !s.canRedo;
  });

  syncUI();
}
