/**
 * keyboard.js — global shortcuts.
 */

import { state } from "../state.js";
import { MODES } from "../config.js";
import { setMode, doUndo, doRedo, cycleSize, cycleColor, removeSelected, exportPng, exportSvg, setGrid } from "../ui/actions.js";
import { cancelLine, cancelText, commitText } from "./pointer.js";
import { openHelp, closeHelp, toast } from "../ui/overlays.js";
import { el } from "../ui/dom.js";

export function initKeyboard() {
  document.addEventListener("keydown", (e) => {
    const typing = e.target === el.textInput || e.target.tagName === "INPUT" || e.target.tagName === "SELECT";

    if (e.key === "Escape") {
      if (!el.helpOverlay.hidden) return; // handled by overlays
      if (el.textWrap.dataset.open === "true") {
        cancelText();
        return;
      }
      cancelLine();
      return;
    }

    if (typing) return;

    const mod = e.ctrlKey || e.metaKey;

    if (mod && e.key.toLowerCase() === "z") {
      e.preventDefault();
      e.shiftKey ? doRedo() : doUndo();
      return;
    }
    if (mod && e.key.toLowerCase() === "y") {
      e.preventDefault();
      doRedo();
      return;
    }
    if (mod && e.key.toLowerCase() === "s") {
      e.preventDefault();
      e.shiftKey ? exportSvg() : exportPng();
      return;
    }

    if (mod || e.altKey) return;

    // 1..6 → tools
    if (/^[1-6]$/.test(e.key)) {
      const mode = MODES[Number(e.key) - 1];
      if (mode) setMode(mode);
      return;
    }

    switch (e.key.toLowerCase()) {
      case "d":
        setMode("draw");
        break;
      case "v":
        setMode("select");
        break;
      case "s":
        setMode("shape");
        break;
      case "l":
        setMode("line");
        break;
      case "t":
        setMode("text");
        break;
      case "e":
        setMode("eraser");
        break;
      case "[":
        cycleSize();
        break;
      case "]":
        cycleColor();
        break;
      case "g":
        setGrid(!state.showGrid);
        toast(state.showGrid ? "Grid on" : "Grid off", "default", 900);
        break;
      case "delete":
      case "backspace":
        if (removeSelected()) e.preventDefault();
        break;
      case "f":
        toggleFullscreen();
        break;
      case "?":
        openHelp();
        break;
      case "h":
        openHelp();
        break;
      default:
        break;
    }
  });

  el.textInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      commitText();
    }
    if (e.key === "Escape") {
      e.preventDefault();
      cancelText();
    }
    e.stopPropagation();
  });
}

export function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen?.().catch(() => {});
  } else {
    document.exitFullscreen?.().catch(() => {});
  }
}

export { closeHelp };
