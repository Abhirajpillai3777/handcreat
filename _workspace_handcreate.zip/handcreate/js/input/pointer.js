/**
 * pointer.js — unified mouse / touch / stylus input via Pointer Events.
 * Handles every drawing mode plus object selection, dragging and scaling.
 */

import { state, addObject, removeObject, selectObject, getObject, saveSettings } from "../state.js";
import { LIMITS } from "../config.js";
import { toCanvasPoint, requestArt, requestFx } from "../core/canvas.js";
import { pickObject, moveObject, scaleObject, hitTest } from "../core/renderer.js";
import { commit } from "../core/history.js";
import { play } from "../audio.js";
import { toast, setEmptyState } from "../ui/overlays.js";
import { el } from "../ui/dom.js";

let drawing = false;
let dragging = null; // { id, lastX, lastY, moved }
let erasing = false;
let eraseCommitted = false;
let activePointerId = null;

const shapeRadius = () => state.size * 2.1 + 13;

/* ------------------------------------------------------------------ setup */

export function initPointer() {
  const c = el.artCanvas;

  c.addEventListener("pointerdown", onDown);
  c.addEventListener("pointermove", onMove);
  c.addEventListener("pointerup", onUp);
  c.addEventListener("pointercancel", onUp);
  c.addEventListener("pointerleave", (e) => {
    if (e.buttons === 0) onUp(e);
  });
  c.addEventListener("contextmenu", (e) => e.preventDefault());
  c.addEventListener("wheel", onWheel, { passive: false });
}

function pointFrom(e) {
  return toCanvasPoint(e.clientX, e.clientY);
}

/* ------------------------------------------------------------------- down */

function onDown(e) {
  if (e.button !== undefined && e.button !== 0) return;
  e.preventDefault();
  activePointerId = e.pointerId;
  try {
    el.artCanvas.setPointerCapture?.(e.pointerId);
  } catch {
    /* synthetic or already-released pointer — safe to ignore */
  }

  const { x, y } = pointFrom(e);
  state.pointer.x = x;
  state.pointer.y = y;
  state.pointer.down = true;

  if (state.mode === "select") {
    const hit = pickObject(state.objects, x, y, 12);
    if (hit) {
      selectObject(hit.id);
      dragging = { id: hit.id, lastX: x, lastY: y, moved: false };
      commit();
      el.artCanvas.style.cursor = "grabbing";
    } else {
      selectObject(null);
    }
    return;
  }

  if (state.mode === "draw") {
    startStroke(x, y);
    return;
  }

  if (state.mode === "eraser") {
    erasing = true;
    eraseCommitted = false;
    eraseAt(x, y);
    return;
  }

  if (state.mode === "shape") {
    placeShapeAt(x, y);
    return;
  }

  if (state.mode === "line") {
    lineClickAt(x, y);
    return;
  }

  if (state.mode === "text") {
    openTextAt(x, y);
  }
}

/* ------------------------------------------------------------------- move */

function onMove(e) {
  const { x, y } = pointFrom(e);
  state.pointer.x = x;
  state.pointer.y = y;

  if (dragging) {
    const obj = getObject(dragging.id);
    if (obj) {
      moveObject(obj, x - dragging.lastX, y - dragging.lastY);
      dragging.lastX = x;
      dragging.lastY = y;
      dragging.moved = true;
      requestArt();
    }
    return;
  }

  if (drawing) {
    extendStroke(x, y);
    return;
  }

  if (erasing) {
    eraseAt(x, y);
  }
}

/* --------------------------------------------------------------------- up */

function onUp(e) {
  if (activePointerId !== null && e && e.pointerId !== undefined && e.pointerId !== activePointerId) {
    return;
  }
  activePointerId = null;
  state.pointer.down = false;

  if (dragging) {
    if (dragging.moved) {
      play("tick");
      toast("Moved", "default", 900);
    }
    dragging = null;
    el.artCanvas.style.cursor = state.mode === "select" ? "default" : "crosshair";
    requestArt();
    return;
  }

  if (drawing) {
    drawing = false;
    play("tick");
    return;
  }

  if (erasing) {
    erasing = false;
    eraseCommitted = false;
  }
}

/* ------------------------------------------------------------------ wheel */

function onWheel(e) {
  if (state.mode !== "select" || !state.selectedId) return;
  const obj = getObject(state.selectedId);
  if (!obj) return;
  e.preventDefault();
  const factor = e.deltaY < 0 ? 1.08 : 1 / 1.08;
  scaleObject(obj, factor);
  requestArt();
  requestFx();
}

/* ------------------------------------------------------------- freehand */

function startStroke(x, y) {
  commit();
  drawing = true;
  addObject({
    type: "path",
    color: state.color,
    lineWidth: state.size,
    opacity: state.opacity,
    points: [{ x, y }],
  });
  setEmptyState(false);
  requestArt();
}

function extendStroke(x, y) {
  const path = state.objects[state.objects.length - 1];
  if (!path || path.type !== "path") return;
  const last = path.points[path.points.length - 1];
  if (Math.hypot(x - last.x, y - last.y) < 1.5) return;
  path.points.push({ x, y });
  requestArt();
}

/* ---------------------------------------------------------------- shapes */

export function placeShapeAt(x, y) {
  commit();
  addObject({
    type: state.shape,
    x,
    y,
    r: shapeRadius(),
    color: state.color,
    lineWidth: state.filled ? 2.5 : Math.max(2, state.size * 0.4),
    opacity: state.opacity,
    filled: state.filled,
  });
  setEmptyState(false);
  requestArt();
  play("place");
  toast(`${state.shape} placed`, "accent", 900);
}

/* ------------------------------------------------------------------ line */

export function lineClickAt(x, y) {
  if (!state.lineStart) {
    state.lineStart = { x, y };
    toast("Click again to finish the line", "default", 1400);
    return;
  }
  commit();
  addObject({
    type: "line",
    x1: state.lineStart.x,
    y1: state.lineStart.y,
    x2: x,
    y2: y,
    color: state.color,
    lineWidth: state.size,
    opacity: state.opacity,
  });
  state.lineStart = null;
  setEmptyState(false);
  requestArt();
  play("place");
}

export function cancelLine() {
  if (state.lineStart) {
    state.lineStart = null;
    toast("Line cancelled", "default", 900);
  }
}

/* ------------------------------------------------------------------ text */

export function openTextAt(x, y) {
  state.textPending = { x, y };
  el.textWrap.dataset.open = "true";
  const maxLeft = el.stage.clientWidth - 210;
  const maxTop = el.stage.clientHeight - 60;
  el.textWrap.style.left = `${Math.max(6, Math.min(x, maxLeft))}px`;
  el.textWrap.style.top = `${Math.max(6, Math.min(y, maxTop))}px`;
  el.textInput.value = "";
  el.textInput.focus();
}

export function commitText() {
  const value = el.textInput.value.trim().slice(0, LIMITS.maxTextLength);
  if (value && state.textPending) {
    commit();
    addObject({
      type: "text",
      x: state.textPending.x,
      y: state.textPending.y,
      text: value,
      color: state.color,
      size: state.size * 2.2 + 12,
      opacity: state.opacity,
    });
    setEmptyState(false);
    requestArt();
    play("place");
  }
  el.textWrap.dataset.open = "false";
  el.textInput.value = "";
  state.textPending = null;
}

export function cancelText() {
  el.textWrap.dataset.open = "false";
  el.textInput.value = "";
  state.textPending = null;
}

/* ---------------------------------------------------------------- eraser */

function eraseAt(x, y) {
  const radius = state.size * 2 + 16;
  let removed = false;

  for (let i = state.objects.length - 1; i >= 0; i--) {
    const obj = state.objects[i];
    let hit = false;

    if (obj.type === "path") {
      hit = obj.points.some((p) => Math.hypot(p.x - x, p.y - y) < radius);
    } else if (obj.type === "line") {
      hit = hitTest(obj, x, y, radius);
    } else if (obj.type === "text") {
      hit = hitTest(obj, x, y, radius * 0.5);
    } else {
      hit = Math.hypot(obj.x - x, obj.y - y) < obj.r + radius * 0.5;
    }

    if (hit) {
      if (!eraseCommitted) {
        // commit BEFORE mutating, so undo actually restores the object
        commit();
        eraseCommitted = true;
      }
      removeObject(obj.id);
      removed = true;
    }
  }

  if (removed) {
    requestArt();
    requestFx();
    play("erase");
  }
}

/* ------------------------------------------------- hand-driven equivalents */
/* The hand tracker drives the exact same code paths as the mouse, so a stroke
   drawn with a fingertip is indistinguishable from one drawn with a pointer. */

export function handStrokeStart(x, y) {
  if (!drawing) startStroke(x, y);
}

export function handStrokeMove(x, y) {
  if (drawing) extendStroke(x, y);
}

export function handStrokeEnd() {
  if (drawing) {
    drawing = false;
    play("tick");
  }
}

export function handEraseStart() {
  if (!erasing) {
    erasing = true;
    eraseCommitted = false;
  }
}

export function handEraseMove(x, y) {
  if (erasing) eraseAt(x, y);
}

export function handEraseEnd() {
  erasing = false;
  eraseCommitted = false;
}

export function handSelectStart(x, y) {
  const hit = pickObject(state.objects, x, y, 16);
  if (!hit) {
    selectObject(null);
    return false;
  }
  selectObject(hit.id);
  dragging = { id: hit.id, lastX: x, lastY: y, moved: false };
  commit();
  return true;
}

export function handSelectMove(x, y) {
  if (!dragging) return;
  const obj = getObject(dragging.id);
  if (!obj) return;
  moveObject(obj, x - dragging.lastX, y - dragging.lastY);
  dragging.lastX = x;
  dragging.lastY = y;
  dragging.moved = true;
  requestArt();
}

export function handSelectEnd() {
  if (!dragging) return;
  dragging = null;
  requestArt();
}

/* --------------------------------------------------------------- helpers */

export function deleteSelected() {
  if (!state.selectedId) return false;
  commit();
  removeObject(state.selectedId);
  requestArt();
  requestFx();
  play("erase");
  toast("Deleted", "danger", 900);
  return true;
}

export function updateCursor() {
  const map = {
    select: "default",
    draw: "crosshair",
    shape: "copy",
    line: "crosshair",
    text: "text",
    eraser: "cell",
  };
  el.artCanvas.style.cursor = map[state.mode] || "crosshair";
}
