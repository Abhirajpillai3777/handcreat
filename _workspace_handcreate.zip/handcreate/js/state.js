/**
 * state.js — single source of truth + tiny event bus.
 *
 * Events:
 *   "objects"  — the artwork changed (add / remove / move / undo)
 *   "style"    — colour, size, opacity, fill changed
 *   "mode"     — tool changed
 *   "background" — background preset / colours changed
 *   "settings" — toggles, theme, export options
 *   "history"  — undo/redo availability changed
 *   "selection"— selected object changed
 */

import { DEFAULTS, STORAGE_KEY } from "./config.js";

const listeners = new Map();

export const state = {
  ...structuredClone(DEFAULTS),
  objects: [],
  selectedId: null,
  nextId: 1,
  pointer: { x: 0, y: 0, down: false },
  lineStart: null,
  textPending: null,
  cameraActive: false,
};

/* ------------------------------------------------------------------ bus */

export function on(event, handler) {
  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(handler);
  return () => listeners.get(event).delete(handler);
}

export function emit(event, payload) {
  const set = listeners.get(event);
  if (set) for (const fn of set) fn(payload);
}

/* --------------------------------------------------------------- helpers */

export function uid() {
  return `o${state.nextId++}`;
}

export function addObject(obj) {
  obj.id = obj.id || uid();
  state.objects.push(obj);
  return obj;
}

export function removeObject(id) {
  const i = state.objects.findIndex((o) => o.id === id);
  if (i === -1) return false;
  state.objects.splice(i, 1);
  if (state.selectedId === id) state.selectedId = null;
  return true;
}

export function getObject(id) {
  return state.objects.find((o) => o.id === id) || null;
}

export function selectObject(id) {
  if (state.selectedId === id) return;
  state.selectedId = id;
  emit("selection", id);
}

/* ------------------------------------------------------------ persistence */

const PERSIST_KEYS = [
  "theme",
  "background",
  "showGrid",
  "physics",
  "sound",
  "skeleton",
  "exportScale",
  "transparentExport",
  "color",
  "size",
  "opacity",
  "filled",
  "shape",
];

export function loadSettings() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw);
    for (const key of PERSIST_KEYS) {
      if (saved[key] !== undefined) {
        if (key === "background" && typeof saved[key] === "object") {
          Object.assign(state.background, saved[key]);
        } else {
          state[key] = saved[key];
        }
      }
    }
  } catch {
    /* corrupted storage — ignore */
  }
}

let saveTimer = null;

export function saveSettings() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      const out = {};
      for (const key of PERSIST_KEYS) out[key] = state[key];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(out));
    } catch {
      /* quota / private mode — ignore */
    }
  }, 250);
}
