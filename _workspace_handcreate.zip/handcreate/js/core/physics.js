/**
 * physics.js — optional "gravity" mode.
 * The animation loop only runs while physics is enabled (the original ran
 * requestAnimationFrame forever, even when the toggle was off).
 */

import { state, on } from "../state.js";
import { getSize, requestArt } from "./canvas.js";

let rafId = null;

function step() {
  rafId = null;
  if (!state.physics) return;

  const { height, width } = getSize();
  let moved = false;

  for (const obj of state.objects) {
    if (obj.type === "path" || obj.type === "line" || obj.type === "text") continue;

    if (obj.vy === undefined) {
      obj.vy = 0;
      obj.vx = (Math.random() - 0.5) * 0.5;
    }

    obj.vy += 0.32;
    obj.y += obj.vy;
    obj.x += obj.vx;

    const r = obj.r || 20;
    const floor = height - r - 4;

    if (obj.y > floor) {
      obj.y = floor;
      obj.vy *= -0.62;
      obj.vx *= 0.92;
      if (Math.abs(obj.vy) < 0.5) obj.vy = 0;
    }
    if (obj.x < r) {
      obj.x = r;
      obj.vx = Math.abs(obj.vx) * 0.7;
    }
    if (obj.x > width - r) {
      obj.x = width - r;
      obj.vx = -Math.abs(obj.vx) * 0.7;
    }

    moved = true;
  }

  if (moved) requestArt();
  rafId = requestAnimationFrame(step);
}

export function startPhysics() {
  if (rafId !== null) return;
  rafId = requestAnimationFrame(step);
}

export function stopPhysics() {
  if (rafId !== null) {
    cancelAnimationFrame(rafId);
    rafId = null;
  }
  // remove leftover velocity so objects don't jump when re-enabled
  for (const obj of state.objects) {
    delete obj.vx;
    delete obj.vy;
  }
}

export function initPhysics() {
  on("settings", () => {
    if (state.physics) startPhysics();
    else stopPhysics();
  });
}
