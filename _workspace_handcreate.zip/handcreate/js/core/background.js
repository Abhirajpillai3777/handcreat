/**
 * background.js — paints the artboard background.
 * Shared by the live canvas and the PNG exporter so both always match.
 */

const GRID = 40;

export function paintBackground(ctx, w, h, bg, options = {}) {
  const { transparent = false, showGrid = true } = options;
  const preset = transparent ? "transparent" : bg.preset;
  const c1 = bg.color;
  const c2 = bg.color2;

  ctx.save();
  ctx.clearRect(0, 0, w, h);

  if (preset === "transparent") {
    // nothing painted — real transparency
    ctx.restore();
    return;
  }

  if (preset === "gradient") {
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, c1);
    g.addColorStop(1, c2);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
    return;
  }

  if (preset === "blueprint") {
    ctx.fillStyle = "#0a2540";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "rgba(120, 190, 255, 0.16)";
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 20) {
      ctx.beginPath();
      ctx.moveTo(x + 0.5, 0);
      ctx.lineTo(x + 0.5, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 20) {
      ctx.beginPath();
      ctx.moveTo(0, y + 0.5);
      ctx.lineTo(w, y + 0.5);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(140, 205, 255, 0.34)";
    for (let x = 0; x < w; x += 100) {
      ctx.beginPath();
      ctx.moveTo(x + 0.5, 0);
      ctx.lineTo(x + 0.5, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 100) {
      ctx.beginPath();
      ctx.moveTo(0, y + 0.5);
      ctx.lineTo(w, y + 0.5);
      ctx.stroke();
    }
    ctx.restore();
    return;
  }

  if (preset === "paper") {
    ctx.fillStyle = "#f6f1e7";
    ctx.fillRect(0, 0, w, h);
    // faint fibre texture
    ctx.fillStyle = "rgba(120, 100, 70, 0.045)";
    for (let i = 0; i < (w * h) / 900; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      ctx.fillRect(x, y, 1.4, 1.4);
    }
    ctx.restore();
    return;
  }

  // solid base for grid / dots / solid
  ctx.fillStyle = c1;
  ctx.fillRect(0, 0, w, h);

  if (preset === "grid" && showGrid) {
    ctx.strokeStyle = "rgba(148, 163, 184, 0.16)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 0; x < w; x += GRID) {
      ctx.moveTo(x + 0.5, 0);
      ctx.lineTo(x + 0.5, h);
    }
    for (let y = 0; y < h; y += GRID) {
      ctx.moveTo(0, y + 0.5);
      ctx.lineTo(w, y + 0.5);
    }
    ctx.stroke();
  }

  if (preset === "dots" && showGrid) {
    ctx.fillStyle = "rgba(148, 163, 184, 0.3)";
    for (let x = GRID / 2; x < w; x += GRID) {
      for (let y = GRID / 2; y < h; y += GRID) {
        ctx.beginPath();
        ctx.arc(x, y, 1.3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  ctx.restore();
}

/** Checkerboard used on-screen when the artboard is transparent. */
export function paintCheckerboard(ctx, w, h) {
  const s = 14;
  ctx.save();
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "#e6e9ef";
  for (let y = 0; y < h; y += s) {
    for (let x = 0; x < w; x += s) {
      if (((x / s) | 0) % 2 === ((y / s) | 0) % 2) ctx.fillRect(x, y, s, s);
    }
  }
  ctx.restore();
}
