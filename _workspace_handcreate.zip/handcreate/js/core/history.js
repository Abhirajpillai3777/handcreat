/**
 * history.js — snapshot based undo / redo.
 *
 * IMPORTANT: `commit()` must be called *before* mutating state.objects.
 * The original file called it after erasing, which made undo a no-op.
 */

import { state, emit } from "../state.js";
import { LIMITS } from "../config.js";

const undoStack = [];
const redoStack = [];

function snapshot() {
  return JSON.stringify(state.objects);
}

function restore(json) {
  state.objects = JSON.parse(json);
  state.selectedId = null;
  emit("objects");
  emit("selection", null);
}

export function commit() {
  undoStack.push(snapshot());
  if (undoStack.length > LIMITS.history) undoStack.shift();
  redoStack.length = 0;
  emit("history", status());
}

export function undo() {
  if (!undoStack.length) return false;
  redoStack.push(snapshot());
  restore(undoStack.pop());
  emit("history", status());
  return true;
}

export function redo() {
  if (!redoStack.length) return false;
  undoStack.push(snapshot());
  restore(redoStack.pop());
  emit("history", status());
  return true;
}

export function status() {
  return {
    canUndo: undoStack.length > 0,
    canRedo: redoStack.length > 0,
    depth: undoStack.length,
  };
}
