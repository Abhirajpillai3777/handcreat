/**
 * renderer.js — draws objects onto a 2D context.
 * Stateless: every function receives what it needs.
 */

import { shapePath, strokePath, objectBounds } from "./shapes.js";

const FONT_STACK = 'Inter, system-ui, -apple-system, "Segoe UI", sans-serif';

export function drawObject(ctx, obj) {
  ctx.save();
  ctx.globalAlpha = obj.opacity ?? 1;
  ctx.strokeStyle = obj.color;
  ctx.fillStyle = obj.color;
  ctx.lineWidth = obj.lineWidth ?? 3;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  if (obj.type === "path") {
    const d = strokePath(obj.points);
    if (d) ctx.stroke(new Path2D(d));
  } else if (obj.type === "line") {
    ctx.beginPath();
    ctx.moveTo(obj.x1, obj.y1);
    ctx.lineTo(obj.x2, obj.y2);
    ctx.stroke();
  } else if (obj.type === "text") {
    ctx.font = `650 ${obj.size}px ${FONT_STACK}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(obj.text, obj.x, obj.y);
  } else {
    const path = new Path2D(shapePath(obj.type, obj.x, obj.y, obj.r));
    if (obj.filled) {
      ctx.fill(path);
      ctx.stroke(path);
    } else {
      ctx.stroke(path);
    }
  }

  ctx.restore();
}

export function drawObjects(ctx, objects) {
  for (const obj of objects) drawObject(ctx, obj);
}

export function drawSelection(ctx, obj) {
  if (!obj) return;
  const b = objectBounds(obj);
  const pad = 6;
  ctx.save();
  ctx.strokeStyle = "#22d3ee";
  ctx.lineWidth = 1.5;
  ctx.setLineDash([5, 4]);
  ctx.strokeRect(b.x - pad, b.y - pad, b.w + pad * 2, b.h + pad * 2);
  ctx.setLineDash([]);
  ctx.fillStyle = "#22d3ee";
  for (const [cx, cy] of [
    [b.x - pad, b.y - pad],
    [b.x + b.w + pad, b.y - pad],
    [b.x - pad, b.y + b.h + pad],
    [b.x + b.w + pad, b.y + b.h + pad],
  ]) {
    ctx.beginPath();
    ctx.arc(cx, cy, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/* ------------------------------------------------------------ hit testing */

function distToSegment(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return Math.hypot(px - x1, py - y1);
  let t = ((px - x1) * dx + (py - y1) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
}

/** Returns true if (x, y) hits the object. */
export function hitTest(obj, x, y, tolerance = 10) {
  if (obj.type === "path") {
    const reach = (obj.lineWidth || 3) / 2 + tolerance;
    for (let i = 1; i < obj.points.length; i++) {
      const a = obj.points[i - 1];
      const b = obj.points[i];
      if (distToSegment(x, y, a.x, a.y, b.x, b.y) <= reach) return true;
    }
    return false;
  }
  if (obj.type === "line") {
    return distToSegment(x, y, obj.x1, obj.y1, obj.x2, obj.y2) <= (obj.lineWidth || 3) / 2 + tolerance;
  }
  if (obj.type === "text") {
    const b = objectBounds(obj);
    return x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;
  }
  return Math.hypot(obj.x - x, obj.y - y) <= obj.r + tolerance;
}

/** Topmost object at a point (objects are painted in array order). */
export function pickObject(objects, x, y, tolerance = 10) {
  for (let i = objects.length - 1; i >= 0; i--) {
    if (hitTest(objects[i], x, y, tolerance)) return objects[i];
  }
  return null;
}

/* -------------------------------------------------------------- transform */

export function moveObject(obj, dx, dy) {
  if (obj.type === "path") {
    for (const p of obj.points) {
      p.x += dx;
      p.y += dy;
    }
  } else if (obj.type === "line") {
    obj.x1 += dx;
    obj.y1 += dy;
    obj.x2 += dx;
    obj.y2 += dy;
  } else {
    obj.x += dx;
    obj.y += dy;
  }
}

export function scaleObject(obj, factor) {
  const f = Math.max(0.25, Math.min(4, factor));
  if (obj.type === "path") {
    const b = objectBounds(obj);
    const cx = b.x + b.w / 2;
    const cy = b.y + b.h / 2;
    for (const p of obj.points) {
      p.x = cx + (p.x - cx) * f;
      p.y = cy + (p.y - cy) * f;
    }
    obj.lineWidth = Math.max(1, (obj.lineWidth || 3) * f);
  } else if (obj.type === "line") {
    const cx = (obj.x1 + obj.x2) / 2;
    const cy = (obj.y1 + obj.y2) / 2;
    obj.x1 = cx + (obj.x1 - cx) * f;
    obj.y1 = cy + (obj.y1 - cy) * f;
    obj.x2 = cx + (obj.x2 - cx) * f;
    obj.y2 = cy + (obj.y2 - cy) * f;
    obj.lineWidth = Math.max(1, (obj.lineWidth || 3) * f);
  } else if (obj.type === "text") {
    obj.size = Math.max(8, Math.min(220, obj.size * f));
  } else {
    obj.r = Math.max(4, Math.min(400, obj.r * f));
  }
}
