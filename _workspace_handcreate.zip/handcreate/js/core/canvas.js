/**
 * canvas.js — owns the three canvas layers and the render loop.
 *
 *   #bg-canvas  → background preset (never exported directly)
 *   #art-canvas → the artwork (this is what gets exported)
 *   #fx-canvas  → cursor, hand skeleton, selection (never exported)
 *
 * Rendering is dirty-flag based: nothing repaints unless something changed.
 */

import { state, on, emit } from "../state.js";
import { drawObjects, drawSelection } from "./renderer.js";
import { paintBackground, paintCheckerboard } from "./background.js";

const layers = {
  bg: null,
  art: null,
  fx: null,
};

let ctx = { bg: null, art: null, fx: null };
let dpr = 1;
let width = 0;
let height = 0;

let artDirty = true;
let bgDirty = true;
let fxDirty = true;
let rafId = null;

/* ------------------------------------------------------------- lifecycle */

export function initCanvases() {
  layers.bg = document.getElementById("bg-canvas");
  layers.art = document.getElementById("art-canvas");
  layers.fx = document.getElementById("fx-canvas");

  ctx.bg = layers.bg.getContext("2d");
  ctx.art = layers.art.getContext("2d");
  ctx.fx = layers.fx.getContext("2d");

  resize();

  const ro = new ResizeObserver(() => resize());
  ro.observe(document.querySelector(".stage"));

  on("objects", () => {
    artDirty = true;
    fxDirty = true;
    schedule();
  });
  on("style", () => {
    artDirty = true;
    schedule();
  });
  on("background", () => {
    bgDirty = true;
    schedule();
  });
  on("selection", () => {
    fxDirty = true;
    schedule();
  });

  start();
}

export function resize() {
  const stage = document.querySelector(".stage");
  if (!stage) return;

  dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const rect = stage.getBoundingClientRect();
  width = Math.max(1, Math.round(rect.width));
  height = Math.max(1, Math.round(rect.height));

  for (const key of ["bg", "art", "fx"]) {
    const c = layers[key];
    c.width = Math.round(width * dpr);
    c.height = Math.round(height * dpr);
    ctx[key].setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  bgDirty = true;
  artDirty = true;
  fxDirty = true;
  schedule();
  emit("resize", { width, height });
}

export function getSize() {
  return { width, height, dpr };
}

/* --------------------------------------------------------------- render */

function paintBackgroundLayer() {
  const { preset } = state.background;
  if (preset === "transparent") {
    paintCheckerboard(ctx.bg, width, height);
  } else {
    paintBackground(ctx.bg, width, height, state.background, {
      showGrid: state.showGrid,
    });
  }
}

function paintArtLayer() {
  ctx.art.clearRect(0, 0, width, height);
  drawObjects(ctx.art, state.objects);
}

let fxPainter = null;

/**
 * Register an extra painter for the fx layer (hand skeleton, cursor, …).
 * It runs after the selection outline on every fx repaint.
 */
export function setFxPainter(fn) {
  fxPainter = fn;
  requestFx();
}

function paintFxLayer() {
  ctx.fx.clearRect(0, 0, width, height);
  const selected = state.objects.find((o) => o.id === state.selectedId);
  if (selected) drawSelection(ctx.fx, selected);
  if (fxPainter) fxPainter(ctx.fx, width, height);
}

function frame() {
  rafId = null;
  if (bgDirty) {
    paintBackgroundLayer();
    bgDirty = false;
  }
  if (artDirty) {
    paintArtLayer();
    artDirty = false;
  }
  if (fxDirty) {
    paintFxLayer();
    fxDirty = false;
  }
}

export function schedule() {
  if (rafId !== null) return;
  rafId = requestAnimationFrame(frame);
}

export function requestArt() {
  artDirty = true;
  schedule();
}

export function requestFx() {
  fxDirty = true;
  schedule();
}

function start() {
  schedule();
}

/* ----------------------------------------------------------- coordinates */

/** Convert a pointer event position to canvas-space pixels. */
export function toCanvasPoint(clientX, clientY) {
  const rect = layers.art.getBoundingClientRect();
  return {
    x: ((clientX - rect.left) / rect.width) * width,
    y: ((clientY - rect.top) / rect.height) * height,
  };
}

/** Canvas-space → CSS pixels inside the stage (for HTML overlays). */
