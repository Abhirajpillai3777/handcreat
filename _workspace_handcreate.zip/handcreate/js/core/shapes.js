/**
 * shapes.js — pure geometry.
 *
 * Every shape is described once as an SVG path string, which is then used by
 * BOTH renderers: canvas via `new Path2D(d)` and SVG export via `<path d>`.
 * That guarantees the exported file matches the screen exactly.
 */

const TAU = Math.PI * 2;

const n = (v) => Math.round(v * 100) / 100;

function polyPoints(cx, cy, sides, radius, rotation = -Math.PI / 2) {
  const pts = [];
  for (let i = 0; i < sides; i++) {
    const a = rotation + (i * TAU) / sides;
    pts.push([cx + Math.cos(a) * radius, cy + Math.sin(a) * radius]);
  }
  return pts;
}

function pointsToPath(pts, close = true) {
  let d = "";
  pts.forEach(([x, y], i) => {
    d += `${i === 0 ? "M" : "L"}${n(x)} ${n(y)}`;
  });
  return close ? `${d}Z` : d;
}

function roundedRectD(x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  return (
    `M${n(x + rr)} ${n(y)}` +
    `H${n(x + w - rr)}A${n(rr)} ${n(rr)} 0 0 1 ${n(x + w)} ${n(y + rr)}` +
    `V${n(y + h - rr)}A${n(rr)} ${n(rr)} 0 0 1 ${n(x + w - rr)} ${n(y + h)}` +
    `H${n(x + rr)}A${n(rr)} ${n(rr)} 0 0 1 ${n(x)} ${n(y + h - rr)}` +
    `V${n(y + rr)}A${n(rr)} ${n(rr)} 0 0 1 ${n(x + rr)} ${n(y)}Z`
  );
}

function starD(cx, cy, outer, inner, spikes = 5) {
  const pts = [];
  const step = Math.PI / spikes;
  let rot = -Math.PI / 2;
  for (let i = 0; i < spikes; i++) {
    pts.push([cx + Math.cos(rot) * outer, cy + Math.sin(rot) * outer]);
    rot += step;
    pts.push([cx + Math.cos(rot) * inner, cy + Math.sin(rot) * inner]);
    rot += step;
  }
  return pointsToPath(pts);
}

/**
 * Build the path string for a shape.
 * @param {string} type
 * @param {number} x centre x
 * @param {number} y centre y
 * @param {number} r radius (drives overall size)
 * @returns {string} SVG path data
 */
export function shapePath(type, x, y, r) {
  switch (type) {
    case "circle":
      return `M${n(x - r)} ${n(y)}A${n(r)} ${n(r)} 0 1 0 ${n(x + r)} ${n(y)}A${n(r)} ${n(r)} 0 1 0 ${n(x - r)} ${n(y)}Z`;

    case "ellipse": {
      const rx = r * 1.35;
      const ry = r * 0.85;
      return `M${n(x - rx)} ${n(y)}A${n(rx)} ${n(ry)} 0 1 0 ${n(x + rx)} ${n(y)}A${n(rx)} ${n(ry)} 0 1 0 ${n(x - rx)} ${n(y)}Z`;
    }

    case "square": {
      const s = r * 1.55;
      return pointsToPath([
        [x - s / 2, y - s / 2],
        [x + s / 2, y - s / 2],
        [x + s / 2, y + s / 2],
        [x - s / 2, y + s / 2],
      ]);
    }

    case "roundrect": {
      const s = r * 1.55;
      return roundedRectD(x - s / 2, y - s / 2, s, s, s * 0.24);
    }

    case "triangle":
      return pointsToPath(polyPoints(x, y, 3, r * 1.25));

    case "diamond":
      return pointsToPath([
        [x, y - r * 1.3],
        [x + r * 0.92, y],
        [x, y + r * 1.3],
        [x - r * 0.92, y],
      ]);

    case "pentagon":
      return pointsToPath(polyPoints(x, y, 5, r * 1.18));

    case "hexagon":
      return pointsToPath(polyPoints(x, y, 6, r * 1.12));

    case "octagon":
      return pointsToPath(polyPoints(x, y, 8, r * 1.08));

    case "star":
      return starD(x, y, r * 1.28, r * 0.55, 5);

    case "heart": {
      const s = r * 0.95;
      return (
        `M${n(x)} ${n(y + s * 0.62)}` +
        `C${n(x - s * 0.32)} ${n(y + s * 0.22)} ${n(x - s * 1.12)} ${n(y - s * 0.18)} ${n(x - s * 0.98)} ${n(y - s * 0.72)}` +
        `C${n(x - s * 0.86)} ${n(y - s * 1.18)} ${n(x - s * 0.18)} ${n(y - s * 1.16)} ${n(x)} ${n(y - s * 0.72)}` +
        `C${n(x + s * 0.18)} ${n(y - s * 1.16)} ${n(x + s * 0.86)} ${n(y - s * 1.18)} ${n(x + s * 0.98)} ${n(y - s * 0.72)}` +
        `C${n(x + s * 1.12)} ${n(y - s * 0.18)} ${n(x + s * 0.32)} ${n(y + s * 0.22)} ${n(x)} ${n(y + s * 0.62)}Z`
      );
    }

    case "arrow": {
      const s = r * 1.15;
      return pointsToPath([
        [x - s * 0.95, y - s * 0.34],
        [x + s * 0.16, y - s * 0.34],
        [x + s * 0.16, y - s * 0.72],
        [x + s * 1.0, y],
        [x + s * 0.16, y + s * 0.72],
        [x + s * 0.16, y + s * 0.34],
        [x - s * 0.95, y + s * 0.34],
      ]);
    }

    case "cross": {
      const s = r * 1.05;
      const t = s * 0.36;
      return pointsToPath([
        [x - t, y - s],
        [x + t, y - s],
        [x + t, y - t],
        [x + s, y - t],
        [x + s, y + t],
        [x + t, y + t],
        [x + t, y + s],
        [x - t, y + s],
        [x - t, y + t],
        [x - s, y + t],
        [x - s, y - t],
        [x - t, y - t],
      ]);
    }

    case "moon": {
      const outer = r * 1.15;
      const inner = r * 0.86;
      return (
        `M${n(x)} ${n(y - outer)}` +
        `A${n(outer)} ${n(outer)} 0 1 0 ${n(x)} ${n(y + outer)}` +
        `A${n(inner)} ${n(inner)} 0 1 1 ${n(x)} ${n(y - outer)}Z`
      );
    }

    case "bolt": {
      const s = r * 1.2;
      return pointsToPath([
        [x - s * 0.1, y - s],
        [x + s * 0.62, y - s * 0.1],
        [x + s * 0.16, y - s * 0.1],
        [x + s * 0.42, y + s],
        [x - s * 0.6, y + s * 0.02],
        [x - s * 0.12, y + s * 0.02],
      ]);
    }

    case "cloud": {
      const s = r;
      return (
        `M${n(x - s * 0.92)} ${n(y + s * 0.42)}` +
        `C${n(x - s * 1.22)} ${n(y + s * 0.42)} ${n(x - s * 1.28)} ${n(y - s * 0.06)} ${n(x - s * 0.88)} ${n(y - s * 0.12)}` +
        `C${n(x - s * 0.9)} ${n(y - s * 0.72)} ${n(x - s * 0.18)} ${n(y - s * 0.9)} ${n(x + s * 0.06)} ${n(y - s * 0.42)}` +
        `C${n(x + s * 0.36)} ${n(y - s * 0.95)} ${n(x + s * 1.02)} ${n(y - s * 0.6)} ${n(x + s * 0.96)} ${n(y - s * 0.08)}` +
        `C${n(x + s * 1.34)} ${n(y - s * 0.08)} ${n(x + s * 1.34)} ${n(y + s * 0.42)} ${n(x + s * 0.94)} ${n(y + s * 0.42)}Z`
      );
    }

    default:
      return `M${n(x - r)} ${n(y)}A${n(r)} ${n(r)} 0 1 0 ${n(x + r)} ${n(y)}A${n(r)} ${n(r)} 0 1 0 ${n(x - r)} ${n(y)}Z`;
  }
}

/**
 * Smooth freehand stroke: quadratic curves through midpoints.
 * @param {{x:number,y:number}[]} points
 */
export function strokePath(points) {
  if (!points || points.length < 2) return "";
  let d = `M${n(points[0].x)} ${n(points[0].y)}`;
  for (let i = 1; i < points.length - 1; i++) {
    const p = points[i];
    const next = points[i + 1];
    const mx = (p.x + next.x) / 2;
    const my = (p.y + next.y) / 2;
    d += `Q${n(p.x)} ${n(p.y)} ${n(mx)} ${n(my)}`;
  }
  const last = points[points.length - 1];
  d += `L${n(last.x)} ${n(last.y)}`;
  return d;
}

/** Bounding box of an object, in canvas pixels. */
export function objectBounds(obj) {
  if (obj.type === "path") {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const p of obj.points) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }
    const pad = (obj.lineWidth || 3) / 2;
    return { x: minX - pad, y: minY - pad, w: maxX - minX + pad * 2, h: maxY - minY + pad * 2 };
  }
  if (obj.type === "line") {
    const pad = (obj.lineWidth || 3) / 2;
    return {
      x: Math.min(obj.x1, obj.x2) - pad,
      y: Math.min(obj.y1, obj.y2) - pad,
      w: Math.abs(obj.x2 - obj.x1) + pad * 2,
      h: Math.abs(obj.y2 - obj.y1) + pad * 2,
    };
  }
  if (obj.type === "text") {
    const w = obj.text.length * obj.size * 0.62;
    return { x: obj.x - w / 2, y: obj.y - obj.size * 0.7, w, h: obj.size * 1.4 };
  }
  const r = obj.r * 1.4;
  return { x: obj.x - r, y: obj.y - r, w: r * 2, h: r * 2 };
}
