/**
 * audio.js — tiny WebAudio feedback. Lazily created on first user gesture so
 * browsers don't block it.
 */

import { state } from "./state.js";

let ctx = null;

const TONES = {
  place: { freq: 880, dur: 0.11, gain: 0.07, type: "sine" },
  erase: { freq: 240, dur: 0.09, gain: 0.05, type: "triangle" },
  mode: { freq: 620, dur: 0.07, gain: 0.045, type: "sine" },
  color: { freq: 1040, dur: 0.07, gain: 0.045, type: "sine" },
  error: { freq: 180, dur: 0.16, gain: 0.06, type: "sawtooth" },
  tick: { freq: 1400, dur: 0.035, gain: 0.03, type: "square" },
};

function ensure() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") ctx.resume().catch(() => {});
  return ctx;
}

export function play(kind) {
  if (!state.sound) return;
  const tone = TONES[kind] || TONES.mode;
  const ac = ensure();
  if (!ac) return;

  try {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = tone.type;
    osc.frequency.value = tone.freq;
    osc.connect(gain);
    gain.connect(ac.destination);

    const t = ac.currentTime;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(tone.gain, t + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + tone.dur);

    osc.start(t);
    osc.stop(t + tone.dur + 0.02);
  } catch {
    /* audio is optional */
  }
}

/** Unlock audio on the first interaction (required by mobile Safari). */
export function unlockAudio() {
  const ac = ensure();
  if (ac && ac.state === "suspended") ac.resume().catch(() => {});
}
