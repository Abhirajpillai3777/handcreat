/**
 * svg.js — vector export.
 * Every shape now exports as its real geometry (the original collapsed star,
 * heart, arrow, cross, moon, bolt and cloud into circles).
 */

import { state } from "../state.js";
import { getSize } from "../core/canvas.js";
import { shapePath, strokePath } from "../core/shapes.js";

const FONT_STACK = "Inter, system-ui, -apple-system, sans-serif";

function esc(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function num(v) {
  return Math.round(v * 100) / 100;
}

function backgroundSvg(width, height, transparent) {
  if (transparent) return "";
  const { preset, color, color2 } = state.background;

  if (preset === "gradient") {
    return (
      `<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">` +
      `<stop offset="0" stop-color="${color}"/><stop offset="1" stop-color="${color2}"/>` +
      `</linearGradient></defs>` +
      `<rect width="${width}" height="${height}" fill="url(#bg)"/>`
    );
  }
  if (preset === "blueprint") {
    return `<rect width="${width}" height="${height}" fill="#0a2540"/>`;
  }
  if (preset === "paper") {
    return `<rect width="${width}" height="${height}" fill="#f6f1e7"/>`;
  }

  let out = `<rect width="${width}" height="${height}" fill="${color}"/>`;

  if (preset === "grid" && state.showGrid) {
    let d = "";
    for (let x = 0; x <= width; x += 40) d += `M${x} 0V${height}`;
    for (let y = 0; y <= height; y += 40) d += `M0 ${y}H${width}`;
    out += `<path d="${d}" stroke="rgba(148,163,184,0.16)" stroke-width="1" fill="none"/>`;
  }
  if (preset === "dots" && state.showGrid) {
    let circles = "";
    for (let x = 20; x < width; x += 40) {
      for (let y = 20; y < height; y += 40) {
        circles += `<circle cx="${x}" cy="${y}" r="1.3"/>`;
      }
    }
    out += `<g fill="rgba(148,163,184,0.3)">${circles}</g>`;
  }
  return out;
}

function objectSvg(obj) {
  const opacity = obj.opacity ?? 1;
  const color = obj.color;
  const lw = obj.lineWidth ?? 3;

  if (obj.type === "path") {
    const d = strokePath(obj.points);
    if (!d) return "";
    return `<path d="${d}" fill="none" stroke="${color}" stroke-width="${num(lw)}" stroke-linecap="round" stroke-linejoin="round" opacity="${opacity}"/>`;
  }

  if (obj.type === "line") {
    return `<line x1="${num(obj.x1)}" y1="${num(obj.y1)}" x2="${num(obj.x2)}" y2="${num(obj.y2)}" stroke="${color}" stroke-width="${num(lw)}" stroke-linecap="round" opacity="${opacity}"/>`;
  }

  if (obj.type === "text") {
    return `<text x="${num(obj.x)}" y="${num(obj.y)}" fill="${color}" font-family="${FONT_STACK}" font-size="${num(obj.size)}" font-weight="650" text-anchor="middle" dominant-baseline="central" opacity="${opacity}">${esc(obj.text)}</text>`;
  }

  const d = shapePath(obj.type, obj.x, obj.y, obj.r);
  const fill = obj.filled ? color : "none";
  return `<path d="${d}" fill="${fill}" stroke="${color}" stroke-width="${num(lw)}" stroke-linejoin="round" opacity="${opacity}"/>`;
}

export function buildSvg({ transparent = false } = {}) {
  const { width, height } = getSize();
  const body = state.objects.map(objectSvg).join("");

  return (
    `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">` +
    backgroundSvg(width, height, transparent) +
    body +
    `</svg>`
  );
}

export function downloadSvg(options = {}) {
  const svg = buildSvg(options);
  const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `handcreate-${Date.now()}.svg`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  return svg;
}
