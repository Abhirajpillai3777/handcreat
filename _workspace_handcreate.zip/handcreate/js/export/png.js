/**
 * png.js — raster export.
 * Renders the artwork to an offscreen canvas at the requested scale, with the
 * background painted separately so the grid is never baked into the artwork.
 */

import { state } from "../state.js";
import { getSize } from "../core/canvas.js";
import { drawObjects } from "../core/renderer.js";
import { paintBackground } from "../core/background.js";

export function renderToCanvas({ scale = 2, transparent = false } = {}) {
  const { width, height } = getSize();
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(width * scale);
  canvas.height = Math.round(height * scale);

  const ctx = canvas.getContext("2d");
  ctx.setTransform(scale, 0, 0, scale, 0, 0);

  paintBackground(ctx, width, height, state.background, {
    transparent,
    showGrid: state.showGrid,
  });

  drawObjects(ctx, state.objects);
  return canvas;
}

export function downloadPng(options = {}) {
  const canvas = renderToCanvas(options);
  const url = canvas.toDataURL("image/png");
  const a = document.createElement("a");
  a.href = url;
  a.download = `handcreate-${stamp()}.png`;
  a.click();
  return canvas;
}

export async function copyPng(options = {}) {
  const canvas = renderToCanvas(options);
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
  if (!blob) throw new Error("Could not create image");

  if (!navigator.clipboard || !window.ClipboardItem) {
    throw new Error("Clipboard images are not supported in this browser");
  }
  await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
}

function stamp() {
  const d = new Date();
  const p = (v) => String(v).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
