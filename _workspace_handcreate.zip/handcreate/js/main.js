/**
 * main.js — application bootstrap.
 */

import { state, loadSettings, on } from "./state.js";
import { initCanvases, requestArt } from "./core/canvas.js";
import { initPhysics } from "./core/physics.js";
import { initTheme } from "./ui/theme.js";
import { initControls } from "./ui/controls.js";
import { initOverlays, setEmptyState, openHelp } from "./ui/overlays.js";
import { initPointer } from "./input/pointer.js";
import { initKeyboard } from "./input/keyboard.js";
import { initHands, handleResults, trackingStats } from "./input/hands.js";
import { setHud, setStatus } from "./ui/hud.js";
import { unlockAudio } from "./audio.js";

const FIRST_RUN_KEY = "handcreate:seen-help:v1";

function boot() {
  loadSettings();

  initTheme();
  initCanvases();
  initOverlays();
  initControls();
  initPointer();
  initKeyboard();
  initHands();
  initPhysics();

  setEmptyState(true);
  setStatus("Ready · mouse mode", false);
  setHud({
    emoji: "🖱️",
    label: "Ready to draw",
    hint: "Pick a tool on the left, or turn on the camera for gestures",
    progress: 0,
    idle: true,
  });

  on("objects", () => setEmptyState(state.objects.length === 0));

  // first-run onboarding
  if (!localStorage.getItem(FIRST_RUN_KEY)) {
    setTimeout(() => openHelp(), 350);
    localStorage.setItem(FIRST_RUN_KEY, "1");
  }

  // unlock audio on first interaction
  const unlock = () => {
    unlockAudio();
    window.removeEventListener("pointerdown", unlock);
    window.removeEventListener("keydown", unlock);
  };
  window.addEventListener("pointerdown", unlock, { once: true });
  window.addEventListener("keydown", unlock, { once: true });

  // keep UI in sync after a resize (canvas re-renders itself)
  on("resize", () => requestArt());

  // warn before leaving with unsaved work
  window.addEventListener("beforeunload", (e) => {
    if (state.objects.length > 0) {
      e.preventDefault();
      e.returnValue = "";
    }
  });

  // expose a tiny debug handle (handy when filing issues)
  window.handcreate = {
    state,
    version: "2.0.0",
    // Debug helpers: feed synthetic MediaPipe results, inspect tracking health.
    feed: handleResults,
    tracking: trackingStats,
  };
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", boot);
} else {
  boot();
}
