/**
 * config.js — constants and defaults. No imports, no side effects.
 */

export const MODES = ["select", "draw", "shape", "line", "text", "eraser"];

export const SHAPES = [
  "circle",
  "ellipse",
  "square",
  "roundrect",
  "triangle",
  "diamond",
  "pentagon",
  "hexagon",
  "octagon",
  "star",
  "heart",
  "arrow",
  "cross",
  "moon",
  "bolt",
  "cloud",
];

export const SHAPE_LABELS = {
  circle: "Circle",
  ellipse: "Ellipse",
  square: "Square",
  roundrect: "Rounded",
  triangle: "Triangle",
  diamond: "Diamond",
  pentagon: "Pentagon",
  hexagon: "Hexagon",
  octagon: "Octagon",
  star: "Star",
  heart: "Heart",
  arrow: "Arrow",
  cross: "Cross",
  moon: "Moon",
  bolt: "Bolt",
  cloud: "Cloud",
};

export const PALETTE = [
  "#22d3ee",
  "#38bdf8",
  "#818cf8",
  "#a78bfa",
  "#e879f9",
  "#fb7185",
  "#f87171",
  "#fb923c",
  "#fbbf24",
  "#a3e635",
  "#34d399",
  "#2dd4bf",
  "#f8fafc",
  "#94a3b8",
  "#1e293b",
];

export const SIZE_STEPS = [3, 5, 8, 12, 16, 22, 28, 36, 48];

export const BG_PRESETS = [
  { id: "grid", label: "Grid" },
  { id: "dots", label: "Dots" },
  { id: "solid", label: "Solid" },
  { id: "gradient", label: "Gradient" },
  { id: "blueprint", label: "Blueprint" },
  { id: "paper", label: "Paper" },
];

export const DEFAULTS = {
  mode: "draw",
  shape: "circle",
  filled: true,
  color: "#22d3ee",
  colorIndex: 0,
  size: 8,
  sizeIndex: 2,
  opacity: 0.95,
  theme: "dark",
  background: {
    preset: "grid",
    color: "#0b1220",
    color2: "#101a2b",
  },
  showGrid: true,
  physics: false,
  sound: false,
  skeleton: true,
  exportScale: 2,
  transparentExport: false,
};

export const LIMITS = {
  history: 60,
  maxObjects: 900,
  maxTextLength: 60,
  minShapeRadius: 8,
  maxShapeRadius: 260,
};

export const STORAGE_KEY = "handcreate:settings:v1";
